include "song.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
this module is to create, delete, add new songs using ID-based system
*/

node *createasong(int time, char *artist, char *song, int id, node *head)
{
    node *temp = malloc(sizeof(node));
    if (temp == NULL)
    {
        printf("MALLOC UNSUCCESSFUL\n");
        return head;
    }
    temp->next = NULL;
    temp->duration = time;
    temp->id = id;
    strcpy(temp->artist_name, artist);
    strcpy(temp->song_name, song);
    
    if (head == NULL)
    {
        head = temp;
        return head;
    }
    
    // insert at back mechanism
    node *temp1 = head;
    while (temp1->next != NULL)
    {
        temp1 = temp1->next;
    }
    temp1->next = temp;

    return head;
}

// deletion of a song by ID

node *deletesong(node *head, int id)
{
    // deletion can be at head of a linked list
    if (head == NULL)
    {
        printf("NO SONG EXISTS BRO !!\n");
        return head;
    }
    
    if (head->id == id)
    {
        node *temp = head;
        head = head->next;
        printf("DELETED THE SONG: %s (ID: %d)\n", temp->song_name, temp->id);
        free(temp);
        return head;
    }

    node *temp2 = head;
    while (temp2->next != NULL && temp2->next->id != id)
    {
        temp2 = temp2->next;
    }
    
    // if we have reached the last node means the song doesn't exist
    if (temp2->next == NULL)
    {
        printf("ERROR: THE SONG WITH ID %d DOESN'T EXIST\n", id);
        return head;
    }

    node *temp = temp2->next;
    temp2->next = temp->next;
    printf("DELETED THE SONG: %s (ID: %d)\n", temp->song_name, temp->id);
    free(temp);
    return head;
}

// find a song by ID
node *findsongbyid(node *head, int id)
{
    node *temp = head;
    while (temp != NULL)
    {
        if (temp->id == id)
        {
            return temp;
        }
        temp = temp->next;
    }
    return NULL; // song not found
}

// display the songs of linked list on CLI

void display_song(node *head)
{
    node *temp = head;
    // id - song name - artist name - duration
    while (temp != NULL)
    {
        printf("ID: %d | Song: %s | Duration: %d seconds | Artist: %s\n", 
               temp->id, temp->song_name, temp->duration, temp->artist_name);
        temp = temp->next;
    }
}

void savetotxtfile(node *head)
{
    FILE *fptr = fopen("songs.txt", "w");
    if (fptr == NULL)
    {
        printf("ERROR: COULDN'T SAVE IT, SORRY.\n");
        return;
    }

    node *temp = head;
    while (temp != NULL)
    {
        fprintf(fptr, "%d %s %s %d\n", temp->id, temp->song_name, 
                temp->artist_name, temp->duration);
        temp = temp->next;
    }

    fclose(fptr);
    printf("YOUR SAVING PROCESS IS A SUCCESS\n");
}