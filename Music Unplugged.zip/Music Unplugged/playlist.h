
#ifndef PLAYLIST_H
#define PLAYLIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "song.h"

typedef struct playlist
{
    char name[1000];
    int id;
    node *songs;
    struct playlist *next;
} playlist;

playlist *createanew(char *name, int id);
playlist *addnewsong(playlist *l1, node *song);
playlist *deletesongbyid(playlist *l2, int song_id);
void displaywholeplaylist(playlist *p);
node* loopplaylist(playlist *l3);
node* next(node *current, playlist *p);
node* prev(node *current, playlist *p);
playlist *findplaylistbyid(playlist *head, int id);

#endif