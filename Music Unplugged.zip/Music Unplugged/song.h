
#ifndef SONG_H
#define SONG_H

#include <stdio.h>
#include <stdlib.h> 
#include <string.h>

typedef struct node
{
    int duration; // in seconds
    char artist_name[1000];
    char song_name[1000];
    int id;
    struct node *next;
} node;

node *createasong(int time, char *artist, char *song, int id, node *head);
node *deletesong(node *head, int id);
void display_song(node *head);
void savetotxtfile(node *head);
node *findsongbyid(node *head, int id);

#endif