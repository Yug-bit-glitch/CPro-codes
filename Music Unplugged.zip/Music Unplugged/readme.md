the modular structure was 
playlist.c
playlist.h
main.c
album.c
album.h
song.c
song.h
makefile
my initial was a name based system 
in a hurry it is a converted to id based 
in limited time i tried my best to convert it to id based 
pardon me if bugs are there