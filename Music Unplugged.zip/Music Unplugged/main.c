
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "song.h"
#include "playlist.h"
#include "album.h"

node *songs = NULL;
playlist *pls = NULL;
album *albs = NULL;

int main()
{
    int x = 0;
    char name[1000];
    char artist[1000];
    char playlist_name[1000];
    char delname[1000];
    int id, duration, song_id, album_id;

    playlist *p;
    album *a;
    node *current = NULL;

    while (1)
    {
        printf("\n1) ADD A SONG\n");
        printf("2) LOAD A SONG BY ID\n");
        printf("3) DISPLAY ALL SONGS\n");
        printf("4) DELETE A SONG BY ID\n");
        printf("5) CREATE A PLAYLIST\n");
        printf("6) ADD SONG TO PLAYLIST\n");
        printf("7) DELETE SONG FROM PLAYLIST\n");
        printf("8) DISPLAY A PLAYLIST\n");
        printf("9) LOOP PLAYLIST\n");
        printf("10) NEXT SONG IN PLAYLIST\n");
        printf("11) PREVIOUS SONG IN PLAYLIST\n");
        printf("12) CREATE NEW ALBUM\n");
        printf("13) ADD SONG TO ALBUM\n");
        printf("14) DELETE SONG FROM ALBUM\n");
        printf("15) DISPLAY SONGS IN ALBUM\n");
        printf("16) MERGE TWO ALBUMS\n");
        printf("17) DELETE AN ALBUM\n");
        printf("18) EXIT\n");

        scanf("%d", &x);

        switch (x)
        {
        case 1:
            printf("Enter Song Name: ");
            scanf("%s", name);
            printf("Enter Artist Name: ");
            scanf("%s", artist);
            printf("Enter Duration: ");
            scanf("%d", &duration);
            printf("Enter Song ID: ");
            scanf("%d", &id);
            songs = createasong(duration, artist, name, id, songs);
            break;

        case 2:
            printf("Enter Song ID: ");
            scanf("%d", &id);
            findsongbyid(songs, id);
            break;

        case 3:
            display_song(songs);
            break;

        case 4:
            printf("Enter Song ID to delete: ");
            scanf("%d", &id);
            songs = deletesong(songs, id);
            break;

        case 5:
            printf("Enter Playlist Name: ");
            scanf("%s", playlist_name);
            p = createanew(playlist_name);
            p->next = pls;
            pls = p;
            break;

        case 6:
            printf("Enter Playlist Name: ");
            scanf("%s", playlist_name);
            printf("Enter Song ID: ");
            scanf("%d", &id);
            p = pls;
            while (p != NULL && strcmp(p->name, playlist_name) != 0)
            {
                p = p->next;
            }
            if (p != NULL)
            {
                node *s = findsongbyid(songs, id);
                if (s != NULL)
                {
                    addnewsong(p, s);
                }
            }
            break;

        case 7:
            printf("Enter Playlist Name: ");
            scanf("%s", playlist_name);
            printf("Enter Song Name to delete: ");
            scanf("%s", delname);
            p = pls;
            while (p != NULL && strcmp(p->name, playlist_name) != 0)
            {
                p = p->next;
            }
            if (p != NULL)
            {
                deletesong(p, delname);
            }
            break;

        case 8:
            printf("Enter Playlist Name: ");
            scanf("%s", playlist_name);
            p = pls;
            while (p != NULL && strcmp(p->name, playlist_name) != 0)
            {
                p = p->next;
            }
            if (p != NULL)
            {
                displaywholeplaylist(p);
            }
            break;

        case 9:
            printf("Enter Playlist Name: ");
            scanf("%s", playlist_name);
            p = pls;
            while (p != NULL && strcmp(p->name, playlist_name) != 0)
            {
                p = p->next;
            }
            if (p != NULL)
            {
                current = looplaylist(p);
            }
            break;

        case 10:
            if (current != NULL && p != NULL)
            {
                current = next(current, p);
            }
            break;

        case 11:
            if (current != NULL && p != NULL)
            {
                current = prev(current, p);
            }
            break;

        case 12:
            printf("Enter Album Name: ");
            scanf("%s", name);
            printf("Enter Album ID: ");
            scanf("%d", &album_id);
            albs = newalbum(albs, name, album_id);
            break;

        case 13:
            printf("Enter Album ID: ");
            scanf("%d", &album_id);
            printf("Enter Song ID: ");
            scanf("%d", &song_id);
            a = findalbumbyid(albs, album_id);
            if (a != NULL)
            {
                node *s = findsongbyid(songs, song_id);
                if (s != NULL)
                {
                    addsongs(a, s);
                }
            }
            break;

        case 14:
            printf("Enter Album ID: ");
            scanf("%d", &album_id);
            printf("Enter Song ID to delete: ");
            scanf("%d", &song_id);
            a = findalbumbyid(albs, album_id);
            if (a != NULL)
            {
                delsongbyid(a, song_id);
            }
            break;

        case 15:
            printf("Enter Album ID: ");
            scanf("%d", &album_id);
            a = findalbumbyid(albs, album_id);
            if (a != NULL)
            {
                showallsongs(a);
            }
            break;

        case 16:
        {
            int a1, a2;
            printf("Enter Album 1 ID: ");
            scanf("%d", &a1);
            printf("Enter Album 2 ID: ");
            scanf("%d", &a2);
            album *al1 = findalbumbyid(albs, a1);
            album *al2 = findalbumbyid(albs, a2);
            if (al1 != NULL && al2 != NULL)
            {
                albs = mergealbum(al1, al2);
            }
            break;
        }

        case 17:
            printf("Enter Album ID to delete: ");
            scanf("%d", &album_id);
            albs = delalbumbyid(albs, album_id);
            break;

        case 18:
            return 0;

        default:
            break;
        }
    }

    return 0;
}
