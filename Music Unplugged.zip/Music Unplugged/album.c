
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "album.h"

album *newalbum(album *head, char *name, int id)
{
    album *a = malloc(sizeof(album));
    if (a == NULL)
    {
        printf("ERROR: MALLOC FAILED :(\n");
        return head;
    }

    strcpy(a->name, name);
    a->id = id;
    a->next = NULL;
    a->songs = NULL;

    if (head == NULL)
    {
        return a;
    }

    album *temp = head;
    while (temp->next != NULL)
    {
        temp = temp->next;
    }

    temp->next = a;
    return head;
}

void addsongs(album *l1, node *song)
{
    if (l1 == NULL)
    {
        return;
    }

    node *temp = malloc(sizeof(node));
    strcpy(temp->song_name, song->song_name);
    strcpy(temp->artist_name, song->artist_name);
    temp->duration = song->duration;
    temp->id = song->id;
    temp->next = NULL;

    if (l1->songs == NULL)
    {
        l1->songs = temp;
        return;
    }

    node *temp1 = l1->songs;
    while (temp1->next != NULL)
    {
        temp1 = temp1->next;
    }

    temp1->next = temp;
}

void delsongbyid(album *l2, int song_id)
{
    if (l2 == NULL || l2->songs == NULL)
    {
        printf("NO SONGS IN ALBUM\n");
        return;
    }

    node *temp = l2->songs;

    if (temp->id == song_id)
    {
        l2->songs = temp->next;
        free(temp);
        printf("SONG %d REMOVED\n", song_id);
        return;
    }

    node *temp1 = temp->next;
    node *temp2 = temp;

    while (temp1 != NULL)
    {
        if (temp1->id == song_id)
        {
            temp2->next = temp1->next;
            free(temp1);
            printf("SONG %d REMOVED\n", song_id);
            return;
        }

        temp2 = temp1;
        temp1 = temp1->next;
    }

    printf("SONG %d NOT FOUND\n", song_id);
}

node *findinalbumbyid(album *l3, int song_id)
{
    if (l3 == NULL || l3->songs == NULL)
    {
        printf("SEARCH WAS A FAILURE :(\n");
        return NULL;
    }

    node *temp3 = l3->songs;
    while (temp3 != NULL)
    {
        if (temp3->id == song_id)
        {
            return temp3;
        }

        temp3 = temp3->next;
    }

    return NULL;
}

void showallsongs(album *l4)
{
    if (l4 == NULL || l4->songs == NULL)
    {
        printf("BRO HOW CAN I PRINT AN EMPTY ALBUM??\n");
        return;
    }

    node *temp4 = l4->songs;

    while (temp4 != NULL)
    {
        printf("THE SONG IS : %d %s %s %d\n", temp4->id, temp4->song_name, temp4->artist_name, temp4->duration);
        temp4 = temp4->next;
    }
}

album *mergealbum(album *a1, album *a2)
{
    if (a1 == NULL)
        return a2;
    if (a2 == NULL)
        return a1;

    node *tem1 = a1->songs;
    if (tem1 == NULL)
    {
        a1->songs = a2->songs;
        return a1;
    }

    while (tem1->next != NULL)
    {
        tem1 = tem1->next;
    }
    tem1->next = a2->songs;
    return a1;
}

album *findalbumbyid(album *head, int id)
{
    while (head != NULL)
    {
        if (head->id == id)
            return head;
        head = head->next;
    }
    return NULL;
}

album *delalbumbyid(album *head, int id)
{
    if (head == NULL)
    {
        printf("NO ALBUMS EXIST\n");
        return NULL;
    }

    if (head->id == id)
    {
        album *temp = head;
        head = head->next;
        free(temp);
        printf("ALBUM %d DELETED\n", id);
        return head;
    }

    album *temp = head;
    while (temp->next != NULL && temp->next->id != id)
    {
        temp = temp->next;
    }

    if (temp->next == NULL)
    {
        printf("ALBUM %d NOT FOUND\n", id);
        return head;
    }

    album *del = temp->next;
    temp->next = del->next;
    free(del);
    printf("ALBUM %d DELETED\n", id);
    return head;
}
