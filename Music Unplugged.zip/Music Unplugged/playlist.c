#include "playlist.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

playlist *createanew(char *name, int id)
{
    playlist *new = malloc(sizeof(playlist));
    if (new == NULL)
    {
        printf("MALLOC UNSUCCESSFUL\n");
        return NULL;
    }
    strcpy(new->name, name);
    new->id = id;
    new->next = NULL;
    new->songs = NULL;
    /*
    check when to free the new
    */
    printf("YO !! PLAYLIST CREATED SUCCESSFULLY (ID: %d)\n", id);
    return new;
}

playlist *addnewsong(playlist *l1, node *song)
{
    node *newsong = malloc(sizeof(node));
    if (newsong == NULL)
    {
        return l1;
    }

    strcpy(newsong->song_name, song->song_name);
    strcpy(newsong->artist_name, song->artist_name);
    newsong->duration = song->duration;
    newsong->id = song->id;
    newsong->next = NULL;

    if (l1->songs == NULL)
    {
        l1->songs = newsong;
    }
    else
    {
        node *temp = l1->songs;
        while (temp->next != NULL)
        {
            temp = temp->next;
        }
        temp->next = newsong;
    }

    return l1;
}

playlist *deletesongbyid(playlist *l2, int song_id)
{
    if (l2 == NULL || l2->songs == NULL)
    {
        printf("PLAYLIST IS EMPTY BRUH\n");
        return l2;
    }

    node *temp1 = l2->songs;

    if (temp1->id == song_id)
    {
        l2->songs = temp1->next;
        printf("%d REMOVED FROM PLAYLIST\n", song_id);
        free(temp1);
        return l2;
    }

    while (temp1->next != NULL && temp1->next->id != song_id)
    {
        temp1 = temp1->next;
    }

    if (temp1->next == NULL)
    {
        printf("THE SONG %d YOU ARE SEARCHING IS NOT THERE IN PLAYLIST\n", song_id);
        return l2;
    }

    node *l3 = temp1->next;
    temp1->next = l3->next;
    printf("THE SONG %d IS REMOVED FROM THE PLAYLIST\n", song_id);
    free(l3);

    return l2;
}

playlist *findplaylistbyid(playlist *head, int id)
{
    playlist *temp = head;
    while (temp != NULL)
    {
        if (temp->id == id)
        {
            return temp;
        }
        temp = temp->next;
    }
    return NULL; // playlist not found
}

void displaywholeplaylist(playlist *p)
{
    if (p == NULL)
    {
        printf("p IS NULL");
        return;
    }

    if (p->songs == NULL)
    {
        printf("THE PLAYLIST IS EMPTY (SORRY)\n");
        return;
    }

    node *t = p->songs;

    while (t != NULL)
    {
        printf("%d %s %s %d\n", t->id, t->song_name, t->artist_name, t->duration);
        t = t->next;
    }
}

node *loopplaylist(playlist *p)
{
    if (p == NULL || p->songs == NULL)
    {
        printf("ERROR: PLAYLIST IS EMPTY\n");
        return NULL;
    }
    return p->songs;
}

node *next(node *current, playlist *p)
{
    if (current->next != NULL)
    {
        current = current->next;
    }
    else
    {
        current = p->songs;
    }
    return current;
}

node *prev(node *current, playlist *p)
{
    node *t = p->songs;
    if(t->next == NULL){
        printf("PREV NOT POSSIBLE\n");
        return NULL;
    }

    if (current == p->songs)
    {
        while (t->next != NULL)
        {
            t = t->next;
        }
        current = t;
    }
    else
    {
        while (t->next != current)
        {
            t = t->next;
        }
        current = t;
    }
    return current;
}