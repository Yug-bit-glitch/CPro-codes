#ifndef ALBUM_H
#define ALBUM_H

#include "song.h"
#include "playlist.h"

typedef struct album
{
    char name[1000];
    int id;
    node *songs;
    struct album *next;
} album;

album *newalbum(album *head, char *name, int id);
void addsongs(album *l1, node *song);
void delsongbyid(album *l2, int song_id);
node *findinalbumbyid(album *l3, int song_id);
void showallsongs(album *l4);
album *mergealbum(album *a1, album *a2);
album *findalbumbyid(album *head, int id);
album *delalbumbyid(album *head, int id);

#endif